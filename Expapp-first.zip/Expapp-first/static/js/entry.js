document.querySelector('.close').addEventListener("click",
    function () {
	    document.querySelector('.bgm').setAttribute("style", "display:none");
});
